﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RubicCube.UI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void changeColor(object sender)
        {

            RubicCube.BAL.RubicCube rubicCube = new RubicCube.BAL.RubicCube();
            Button button = sender as Button;
            button.BackColor = rubicCube.getColor(button.BackColor);
            button.Focus();
        }

        
        #region Top
        private void Top1_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Top2_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Top3_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Top4_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Top5_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Top6_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Top7_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Top8_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Top9_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }

        #endregion

        #region Bottom
        private void Bottom1_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Bottom2_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Bottom3_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Bottom4_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Bottom5_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Bottom6_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Bottom7_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Bottom8_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Bottom9_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }

        #endregion

        #region Right
        private void Right1_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Right2_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Right3_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Right4_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Right5_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Right6_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Right7_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Right8_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Right9_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }

        #endregion

        #region Left
        private void Left1_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Left2_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Left3_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Left4_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Left5_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Left6_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Left7_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Left8_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Left9_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }

        #endregion

        #region Front
        private void Front1_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Front2_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Front3_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Front4_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Front5_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Front6_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Front7_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Front8_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Front9_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }

        #endregion

        #region Back
        private void Back1_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Back2_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Back3_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Back4_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Back5_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Back6_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Back7_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Back8_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }
        private void Back9_Click(object sender, EventArgs e)
        {
            changeColor(sender);
        }

        #endregion
    }
}
