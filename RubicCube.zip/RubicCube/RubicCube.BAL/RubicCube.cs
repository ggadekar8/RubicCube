﻿using RubicCube.Interfaces;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RubicCube.BAL
{
    public class RubicCube : IRubicCube
    {
        public Color getColor(Color color)
        {
            if (color == Color.Red)
            {
                return Color.Yellow;
            }
            else if (color == Color.Yellow)
            {
                return Color.Orange;
            }
            if (color == Color.Orange)
            {
                return Color.White;
            }
            if (color == Color.White)
            {
                return Color.Green;
            }
            if (color == Color.Green)
            {
                return Color.Blue;
            }
            if (color == Color.Blue)
            {
                return Color.Red;
            }

            return Color.Yellow;
        }
    }
}
